document.getElementById("booking-form").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Заявка успешно отправлена!");
});

function initMap() {
    var mapProp = {
        center: new google.maps.LatLng(56.5, 39.5),
        zoom: 6,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
}

document.addEventListener("DOMContentLoaded", function() {
    var script = document.createElement("script");
    script.src = "https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap";
    document.body.appendChild(script);

    let elements = document.querySelectorAll(".fade-in");

    function fadeInElements() {
        elements.forEach((el) => {
            let rect = el.getBoundingClientRect();
            if (rect.top < window.innerHeight - 50) {
                el.style.opacity = "1";
                el.style.transform = "translateY(0)";
            }
        });
    }

    window.addEventListener("scroll", fadeInElements);
    fadeInElements();
});
